<!DOCTYPE html>
    <html lang="en">
    <head> 

        <meta http-equiv="Content-Type" content="charset=UTF-8">
        <title>Easy learn</title>

        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta name="description" content="Unicat project">
        
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- icons -->
        <link rel="apple-touch-icon" sizes="57x57" href="{{ asset('img/icons/apple-icon-57x57.png')}}">
        <link rel="apple-touch-icon" sizes="60x60" href="{{ asset('img/icons/apple-icon-60x60.png')}}">
        <link rel="apple-touch-icon" sizes="72x72" href="{{ asset('img/icons/apple-icon-72x72.png')}}">
        <link rel="apple-touch-icon" sizes="76x76" href="{{ asset('img/icons/apple-icon-76x76.png')}}">
        <link rel="apple-touch-icon" sizes="114x114" href="{{ asset('img/icons/apple-icon-114x114.png')}}">
        <link rel="apple-touch-icon" sizes="120x120" href="{{ asset('img/icons/apple-icon-120x120.png')}}">
        <link rel="apple-touch-icon" sizes="144x144" href="{{ asset('img/icons/apple-icon-144x144.png')}}">
        <link rel="apple-touch-icon" sizes="152x152" href="{{ asset('img/icons/apple-icon-152x152.png')}}">
        <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('img/icons/apple-icon-180x180.png')}}">
        <link rel="icon" type="image/png" sizes="192x192"  href="/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('img/icons/favicon-32x32.png')}}">
        <link rel="icon" type="image/png" sizes="96x96" href="{{ asset('img/icons/favicon-96x96.png')}}">
        <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('img/icons/favicon-16x16.png')}}">
        <link rel="manifest" href="{{ asset('img/icons/manifest.json')}}">
        <meta name="msapplication-TileImage" content="img/icons/ms-icon-144x144.png">
        
        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css')}}">

        <!-- Fonts -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

        <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

        <!-- Custom fonts for this template -->
        <link rel="stylesheet" type="text/css" href="{{ asset('css/owl.carousel.css')}}">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/owl.theme.default.css')}}">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/animate.css')}}">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/main_styles.css')}}">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/responsive.css')}}">

    </head>
    <body>
        <div class="super_container">

            <!-- Navbar principal -->
            <div class="header_container fixed-top">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="header_content d-flex flex-row align-items-center justify-content-start">
                                <div class="logo_container">
                                    <a href="index.html">
                                        <div class="logo_text">
                                            <img src="{{ asset('img/logo.png')}}" width="40"><span>-learn</span>
                                        </div>
                                    </a>
                                </div>
                                <nav class="main_nav_contaner ml-auto">
                                    <ul class="main_nav">
                                        <li class="active"><a href="#">Inicio</a></li>
                                        <li><a href="#">Asesoria general</a>
                                            <li><a href="#">Contacto</a></li>
                                        </ul>
                                        <div class="hamburger menu_mm">
                                            <i class="fa fa-bars menu_mm" aria-hidden="true"></i>
                                        </div>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Navbar principal -->
            </div>

            <!-- Menu -->
            <div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
                <div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
                <div class="search">
                    <form action="#" class="header_search_form menu_mm">
                        <input type="search" class="search_input menu_mm" placeholder="Buscar cursos" required="required">
                        <button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
                            <i class="fa fa-search menu_mm" aria-hidden="true"></i>
                        </button>
                    </form>
                </div>
                <nav class="menu_nav">
                    <ul class="menu_mm">
                        <li class="menu_mm"><a href="index.html">Inicio</a></li>
                        <li class="menu_mm"><a href="#">Asesoria general</a></li>
                        <li class="menu_mm"><a href="#">Contacto</a></li>
                    </ul>
                </nav>
            </div>
            <!-- End Menu -->

            <!-- Header -->
            <div class="home">
                <header class="masthead bg-primary text-white text-center">
                    <div class="home_slider_background">
                        <div class="home_slider_container">

                            <div class="owl-carousel owl-theme home_slider">

                                <div class="owl-item">
                                    <div class="home_slider_background" style="background-image:url(img/home_slider.jpg)"></div>
                                    <div class="home_slider_content">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col text-center">
                                                    <div class="home_slider_title">Encuentra la mejor asesoria profesional</div>
                                                    <div class="home_slider_subtitle">¡En la comodidad de tu hogar!</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
            </div>
            <!-- End Header -->

            <!-- Bienvenida -->
            <div class="features">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="section_title_container text-center">
                                <h2 class="section_title">Bienvenidos a Easy-learn</h2>
                                <div class="section_subtitle"><p style="font-size: 15px;">En Easy-learn encontraras toda la asesoría general y detallada como también apoyo para tu carrera profesional de derecho.</p></div>
                            </div>
                        </div>
                    </div>
                    <div class="row features_row">

                        <div class="col-lg-6 feature_col">
                            <div class="feature text-center trans_400">
                                <div class="feature_icon"><img src="{{ asset('img/icon_1.png')}}" alt=""></div>
                                <h3 class="feature_title">Somos expertos</h3>
                                <div class="feature_text"><p>Profesionales a tu disposición</p></div>
                            </div>
                        </div>

                        <div class="col-lg-6 feature_col">
                            <div class="feature text-center trans_400">
                                <div class="feature_icon"><img src="{{ asset('img/icon_4.png')}}" alt=""></div>
                                <h3 class="feature_title">Certificación de calidad</h3>
                                <div class="feature_text"><p>Estamos certificados a nivel profesional</p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End bienvenida -->

            <!-- Asesorias -->
            <div class="counter">
                <div class="counter_background" style="background-image:url(img/counter_background.jpg)"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="counter_content">
                                <h2 class="counter_title">Asesorate de la mejor manera</h2>
                                <div class="counter_text"><p>En Easy-learn nos preocupamos por tus metas por ello te brindamos un servicio de calidad.</p></div>


                                <div class="counter_text"><p>Contamos con asesoria a nivel juridico, derecho civil, comercial, familiar, administrativo, penal y laboral</p></div>

                                <div class="milestones d-flex flex-md-row flex-column align-items-center justify-content-between">

                                    <div class="milestone">
                                        <div class="milestone_counter" data-end-value="1" data-sign-after="">1</div>
                                        <div class="milestone_text">Asesor</div>
                                    </div>

                                    <div class="milestone">
                                        <div class="milestone_counter" data-end-value="23" data-sign-after="+">23+</div>
                                        <div class="milestone_text">Estudiantes</div>
                                    </div>

                                    <div class="milestone">
                                        <div class="milestone_counter" data-end-value="2">2</div>
                                        <div class="milestone_text">Años</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="counter_form">
                        <div class="row fill_height">
                            <div class="col fill_height">
                                <form class="counter_form_content d-flex flex-column align-items-center justify-content-center" method="POST" action="{{ route('emails.store') }}">
                                @csrf
                                    <div class="counter_form_title">contáctenme</div>

                                    <input type="text" class="counter_input" placeholder="Nombre" required="required" name="nombre">
                                    <input type="text" class="counter_input" placeholder="Celular" required="required" name="celular">
                                    <textarea class="counter_input counter_text_input" placeholder="Mensaje" required="required" name="mensaje"></textarea>
                                    <button type="submit" class="counter_form_button">Enviar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End asesorias -->

            <!-- Contactenos -->
            <div class="team">
                <div class="team_background parallax-window" data-parallax="scroll" data-image-src="img/team_background.jpg" data-speed="0.8"></div>
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="section_title_container text-center">
                                <h2 class="section_title"></h2>
                                <div class="section_subtitle"><p style="font-size: 15px;">Te brindamos el mejor servicio con los mejores asesores a nivel nacional por eso te ofrecemos la mejor calidad.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 offset-md-3">
                            <div class="team_item text-center" style="margin-bottom: 12px;">
                                <img src="{{ asset('img/logo.png')}}" alt="" width="80">
                            </div>
                            <div class="team_body">
                                <div class="row text-center">
                                    <div class="col-lg-6">
                                        <div class="team_title"><a href="#">Correo electronico</a></div>
                                        <div class="team_subtitle">Asesoriaseasylearn@gmail.com</div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="team_title"><a href="#">Contacto telefónico</a></div>
                                        <div class="team_subtitle">Teléfono: +(57) 310-651-4828</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End contactenos -->

            <!-- Suscripcion -->
            <div class="newsletter">
                <div class="newsletter_background parallax-window" data-parallax="scroll" data-image-src="{{ asset('img/newsletter.jpg')}}" data-speed="0.8"></div>
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="newsletter_container d-flex flex-lg-row flex-column align-items-center justify-content-start">

                                <div class="newsletter_content text-lg-left text-center">
                                    <div class="newsletter_title">Has parte de nuestra comunidad</div>
                                    <div class="newsletter_subtitle">Solo ingresa tu correo electrónico y nos comunicaremos contigo para brindarte la mejor asesoría.</div>
                                </div>

                                <div class="newsletter_form_container ml-lg-auto">
                                    <form action="#" id="newsletter_form" class="newsletter_form d-flex flex-row align-items-center justify-content-center">
                                        <input type="email" class="newsletter_input" placeholder="Tu correo electronico" required="required">
                                        <button type="submit" class="newsletter_button">Suscribirse</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End suscripcion -->

            <footer class="footer">
                <div class="footer_background"></div>
                <div class="container">
                    <div class="row footer_row">
                        <div class="col">
                            <div class="footer_content">
                                <div class="row">
                                    <div class="col-lg-6 footer_col">

                                        <div class="footer_section footer_about">
                                            <div class="logo_container">
                                                <a href="index.html">
                                                    <div class="footer_logo_text">
                                                        <img src="{{ asset('img/logo.png')}}" width="43"><span>-learn</span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="footer_about_text">
                                                <p>Encuentra la mejor asesoria profesional en la comodidad de tu casa.</p>
                                            </div>
                                            <div class="footer_social">
                                                <ul>
                                                    <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-google-plus" aria-hidden="true"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                                                    <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 footer_col">

                                        <div class="footer_section footer_contact">
                                            <div class="footer_title">Contactenos</div>
                                            <div class="footer_contact_info">
                                                <ul>
                                                    <li>Correo electronico: Asesoriaseasylearn@gmail.com</li>
                                                    <li>Teléfono: +(57) 310-651-4828</li>
                                                    <li>Barranquilla, Atlantico, Colombia</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row copyright_row">
                        <div class="col">
                            <div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
                                <div class="cr_text">
                                    Copyright ©<script type="text/javascript">document.write(new Date().getFullYear());</script> All rights reserved.
                                </div>
                                <div class="ml-lg-auto cr_links">
                                    <ul class="cr_list">
                                        <li>Desarrollador por: <a href="https://github.com/Carlosferrerhernandez/" target="_blank">Carlos Ferrer</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
  </body>
        
        @include('sweetalert::alert')

        <!-- Plugin JavaScript -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js" type="text/javascript"></script>
        <script src="{{ asset('js/popper.js')}}" type="text/javascript"></script>

        <!-- Bootstrap core JavaScript -->
        <script src="{{ asset('js/bootstrap.min.js')}}" type="text/javascript"></script>
        <!-- Plugin JavaScript -->
        <script src="{{ asset('js/TweenMax.min.js')}}" type="text/javascript"></script>
        <script src="{{ asset('js/TimelineMax.min.js')}}" type="text/javascript"></script>
        <script src="{{ asset('js/ScrollMagic.min.js')}}" type="text/javascript"></script>
        <script src="{{ asset('js/animation.gsap.min.js')}}" type="text/javascript"></script>
        <script src="{{ asset('js/ScrollToPlugin.min.js')}}" type="text/javascript"></script>
        <script src="{{ asset('js/owl.carousel.js')}}" type="text/javascript"></script>
        <script src="{{ asset('js/easing.js')}}" type="text/javascript"></script>
        <script src="{{ asset('js/parallax.min.js')}}" type="text/javascript"></script>

        <!-- Custom scripts for this template -->
        <script src="{{ asset('js/custom.js')}}" type="text/javascript"></script>
        <script src="{{ asset('js/js')}}" type="text/javascript"></script>

        <script type="text/javascript" charset="utf-8" async defer>
        var host = "easylearncolombia.github.io"
        if (window.location.host == host && window.location.protocol != "https:") {
          window.location.protocol = "https:"
      }
      </script>
</html>
